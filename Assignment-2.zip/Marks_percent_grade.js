// Assigning marks
var m1=78, m2=67, m3=84, m4=66, m5=92;

// Calculating total marks
var total = m1+m2+m3+m4+m5;

// Calculating percentage
var percent = ((m1+m2+m3+m4+m5)/5);

// Printing marks in all 5 subjects
console.log("Eng = ", m1);
console.log("Hin = ", m2);
console.log("Math = ", m3);
console.log("Sci = ", m4);
console.log("S.St = ", m5);

// Printing total marks
console.log("Total marks = ", total);

// Printing percentage
console.log("Percentage = ", percent);

// Assigning grade using if-else condition
if(percent > 90 && percent <=100)
{
    console.log("A Grade");
}
else if(percent > 75 && percent <= 90)
{
    console.log("B Grade");
}
else if(percent > 60 && percent <= 75)
{
    console.log("C Grade");
}
else
{
    console.log("Failed");
}